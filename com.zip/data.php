<?php 

$conn = new mysqli('localhost','root','','com');



$action = 'read';



if (isset($_GET['action'])) {

	$action = $_GET['action'];
}



if ($action == 'insert') {

	$data =  json_decode(file_get_contents('php://input'));

	$name     = $_POST['name'];
	$email    = $_POST['email'];
	$cell     = $_POST['cell'];
	$username = $_POST['username'];


	$data = $conn -> query("INSERT INTO com (name,email,cell,username) VALUES('$name','$email','$cell','$username')");
	
}



if ($action == 'read') {


	$data = $conn -> query("SELECT * FROM com ORDER BY id DESC");


$all_users = [];



while ($user = $data -> fetch_assoc()) {
	array_push($all_users, $user);
}


echo json_encode($all_users);
	
}




if ($action == 'delete') {
	$id =  $_GET['id'];
    $data = $conn -> query("DELETE FROM com WHERE id = '$id'");
}




if ($action == 'search') {
	
	$search = $_GET['s'];


	$data = $conn -> query("SELECT * FROM com WHERE name LIKE '%$search%'");
     

     $search_result = [];

	while ($result = $data -> fetch_assoc()) {

		array_push($search_result, $result);
	}


	echo json_encode($search_result);





}






 ?>